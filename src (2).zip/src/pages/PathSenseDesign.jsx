import { useState } from "react";
import "./pathsense-design.css";

/* ---------- tiny inline icons (no extra packages needed) ---------- */
const I = ({ d, size = 22, fill = "none" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
       strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {d}
  </svg>
);
const icons = {
  camera: <I d={<><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></>} />,
  voice: <I d={<><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></>} />,
  vibe:  <I d={<><path d="m8 7-4 5 4 5M16 7l4 5-4 5M12 5v14"/></>} />,
  pin:   <I d={<><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></>} />,
  user:  <I d={<><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>} />,
  access:<I d={<><circle cx="12" cy="4" r="2"/><path d="M5 8h14M12 8v6l-3 7M12 14l3 7"/></>} />,
  phone: <I d={<><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></>} />,
  info:  <I d={<><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></>} />,
  bell:  <I d={<><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/></>} />,
  chevron:<I size={18} d={<path d="m9 18 6-6-6-6"/>} />,
  alert: <I d={<><path d="m10.3 3.9-8.5 14.7A2 2 0 0 0 3.5 21.6h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></>} />,
  heart: <I fill="currentColor" d={<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>} />,
};

const NAV = [
  ["home", "Home"], ["features", "Features"], ["about", "About"], ["contact", "Contact"],
];

function Navbar({ active, go, onGetStarted }) {
  return (
    <header className="ps-nav">
      <button className="ps-logo" onClick={() => go("home")} aria-label="PathSense home">
        <svg width="34" height="26" viewBox="0 0 34 26" aria-hidden="true" fill="none"
             stroke="#20a78f" strokeWidth="3" strokeLinecap="round">
          <path d="M3 14a14 14 0 0 1 28 0"/><path d="M9 14a8 8 0 0 1 16 0"/><circle cx="17" cy="19" r="2.5" fill="#20a78f"/>
        </svg>
        <span>PathSense</span>
      </button>
      <nav aria-label="Main">
        {NAV.map(([id, label]) => (
          <button key={id} className={active === id ? "on" : ""} onClick={() => go(id)}>{label}</button>
        ))}
      </nav>
      <button className="ps-btn" onClick={onGetStarted}>Get Started</button>
    </header>
  );
}

function Scene({ children, className = "" }) {
  return (
    <div className={`ps-scene ${className}`}>
      <span className="leaf l1" /><span className="leaf l2" /><span className="leaf l3" />
      {children}
    </div>
  );
}

function Phone({ children, dark }) {
  return <div className={`ps-phone ${dark ? "dark" : ""}`}><div className="ps-phone-screen">{children}</div></div>;
}

export default function PathSenseDesign({ onGetStarted = () => {}, onSOS = () => {} }) {
  const [active, setActive] = useState("home");
  const [toggles, setToggles] = useState({ voice: true, vibe: true });

  const go = (id) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="ps-root">
      <Navbar active={active} go={go} onGetStarted={onGetStarted} />

      {/* 1. HOME */}
      <section id="home" className="ps-sec ps-hero">
        <Scene>
          <div className="ps-hero-copy">
            <h1>PathSense<span>A Safer Step<br />for Everyone</span></h1>
            <p>Smart assistance for visually impaired and hearing impaired people. Navigate with confidence, independence and ease.</p>
            <div className="ps-row">
              <button className="ps-btn big" onClick={onGetStarted}>Get Started →</button>
              <button className="ps-btn big ghost" onClick={() => go("features")}>Learn More</button>
            </div>
            <div className="ps-strip">
              <div><i className="c-teal">{icons.camera}</i>Obstacle Detection</div>
              <div><i className="c-blue">{icons.voice}</i>Voice Guidance</div>
              <div><i className="c-purple">{icons.vibe}</i>Vibration Alerts</div>
            </div>
          </div>
          <div className="ps-bubble">{icons.voice}<span>Path is clear ahead</span></div>
          <p className="ps-script">Different needs,<br />Same destination ♡</p>
        </Scene>
      </section>

      {/* 2. FEATURES */}
      <section id="features" className="ps-sec">
        <div className="ps-two">
          <div>
            <p className="ps-kicker">Our Features</p>
            <h2 className="ps-h">Technology for Greater Independence</h2>
            <p className="ps-lead">Simple. Smart. Inclusive.</p>
            <div className="ps-grid2">
              {[
                ["camera","c-blue","Obstacle Detection","Detects obstacles in real-time using your camera."],
                ["voice","c-teal","Voice Guidance","Clear audio instructions for safe navigation."],
                ["vibe","c-pink","Vibration Alerts","Alerts for nearby obstacles and important events."],
                ["pin","c-purple","Safe Navigation","Find the safest and easiest routes in your surroundings."],
              ].map(([ic, c, t, d]) => (
                <article className="ps-card" key={t}><i className={c}>{icons[ic]}</i><h3>{t}</h3><p>{d}</p></article>
              ))}
            </div>
          </div>
          <Phone>
            <b className="ps-app-title">PathSense</b>
            <div className="ps-chip">{icons.voice}<span>Path is clear ahead</span></div>
            <div className="ps-map"><span className="route" /><span className="dot" /></div>
            <div className="ps-tabbar"><span>Home</span><span>Scan</span><span>Settings</span></div>
          </Phone>
        </div>
      </section>

      {/* 3. OBSTACLE TRACKING */}
      <section id="about" className="ps-sec">
        <Scene className="ps-obstacle">
          <h2 className="ps-h">Obstacle Tracking</h2>
          <p className="ps-lead">Detects objects in your path and alerts you in real-time.</p>
          <div className="ps-alert">{icons.alert}<span><b>Obstacle detected</b><br />2 meters ahead</span></div>
          <div className="ps-scanbox" aria-hidden="true"><span>Trash bin</span></div>
          <div className="ps-strip bottom">
            <div><i className="c-blue">{icons.camera}</i>Camera Scan</div>
            <div><i className="c-pink">{icons.vibe}</i>Real-time Detection</div>
            <div><i className="c-purple">{icons.pin}</i>Safe Navigation</div>
          </div>
        </Scene>
      </section>

      {/* 4. LIVE ASSISTANCE */}
      <section className="ps-sec">
        <h2 className="ps-h">Live Assistance</h2>
        <p className="ps-lead">Audio guidance, vibration alerts and real-time support — all in one place.</p>
        <div className="ps-two">
          <Phone dark>
            <b className="ps-app-title light">PathSense</b>
            <div className="ps-turn">↱</div>
            <p className="ps-turn-text">Turn right<br />in 10 meters</p>
            <div className="ps-wave">{Array.from({ length: 11 }).map((_, i) => <i key={i} style={{ height: 8 + ((i * 7) % 5) * 7 }} />)}</div>
          </Phone>
          <div className="ps-stack">
            <article className="ps-card row"><i className="c-teal">{icons.voice}</i><div><h3>Voice Guidance</h3><p>Turn right in 10 meters</p></div></article>
            <article className="ps-card row"><i className="c-purple">{icons.vibe}</i><div><h3>Vibration Alert</h3><p>Small vibration for turns and obstacles</p></div></article>
            <article className="ps-card row"><i className="c-gold">{icons.heart}</i><div><h3>Built for a more independent tomorrow</h3></div></article>
          </div>
        </div>
      </section>

      {/* 5. SETTINGS */}
      <section id="contact" className="ps-sec">
        <h2 className="ps-h">Settings</h2>
        <p className="ps-lead">Personalize your experience for better support.</p>
        <ul className="ps-list">
          {[
            ["user","c-teal","Account","Manage your profile"],
            ["voice","c-teal","Voice Settings","Choose language & voice","voice"],
            ["vibe","c-purple","Vibration Settings","Adjust alert intensity","vibe"],
            ["access","c-navy","Accessibility","Font size, contrast, etc."],
            ["phone","c-orange","Emergency Contacts","Add trusted contacts"],
            ["info","c-teal","About","App version & information"],
          ].map(([ic, c, t, d, key]) => (
            <li key={t}>
              <button className="ps-setting" onClick={() => key && setToggles(s => ({ ...s, [key]: !s[key] }))}>
                <i className={c}>{icons[ic]}</i>
                <span><b>{t}</b><small>{d}</small></span>
                {key
                  ? <em className={`ps-toggle ${toggles[key] ? "on" : ""}`} role="switch" aria-checked={toggles[key]}><u /></em>
                  : icons.chevron}
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* 6. SOS */}
      <section className="ps-sec">
        <Scene className="ps-sos-scene">
          <h2 className="ps-h">SOS / Emergency</h2>
          <p className="ps-lead">Need help? Send an alert to your trusted contacts instantly.</p>
          <div className="ps-two">
            <Phone>
              <button className="ps-sos" onClick={onSOS} aria-label="Send SOS alert">SOS</button>
              <p className="ps-hold">Hold for 3 seconds</p>
              <span className="ps-bell">{icons.bell}</span>
            </Phone>
            <div className="ps-stack">
              <article className="ps-card row"><i className="c-red">{icons.bell}</i><div><h3>Instant Alert</h3><p>Notifies your contacts</p></div></article>
              <article className="ps-card row"><i className="c-blue">{icons.pin}</i><div><h3>Location Share</h3><p>Sends your live location</p></div></article>
              <article className="ps-card row"><i className="c-pink">{icons.bell}</i><div><h3>Quick Help</h3><p>Get support when you need it most</p></div></article>
              <p className="ps-script small">You’re never alone ♡</p>
            </div>
          </div>
        </Scene>
      </section>
    </div>
  );
}
