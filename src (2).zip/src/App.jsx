import { useEffect, useState } from "react";
import { Info } from "lucide-react";

import PathSenseDesign from "./pages/PathSenseDesign";
import DetectionScreen from "./pages/DetectionScreen";
import SettingsScreen from "./pages/SettingsScreen";
import HelpScreen from "./pages/HelpScreen";
import EmergencyScreen from "./pages/EmergencyScreen";
import ReferencePage from "./pages/ReferencePage";
import BottomNavigation from "./components/BottomNavigation";
import { useLocalSettings } from "./utils/useLocalSettings";

const DEFAULT_SETTINGS = {
  alertMode: "both",
  voiceEnabled: true,
  vibrationEnabled: true,
  speechRate: 1,
  largeText: true,
  highContrast: true,
  reducedMotion: false,
  hapticFeedback: true,
  safeDistance: 3,
  dangerDistance: 1.5,
  demoMode: false,
  camera: "environment",
};

const TITLES = {
  home: "Home",
  features: "Features",
  navigation: "Navigation",
  detect: "Obstacle Detection",
  read: "Read Text",
  guardian: "Guardian",
  settings: "Settings",
  more: "More",
  help: "About & Help",
};

export default function App() {
  const [settings, setSettings] = useLocalSettings(
    "pathsense-settings",
    DEFAULT_SETTINGS
  );

  const [screen, setScreen] = useState("home");
  const [emergencyOpen, setEmergencyOpen] = useState(false);
  const [detection, setDetection] = useState(null);

  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState("");
  const [locationLoading, setLocationLoading] = useState(false);

  const [voiceMessage, setVoiceMessage] = useState("");

  useEffect(() => {
    document.documentElement.classList.toggle(
      "large-text",
      settings.largeText
    );

    document.documentElement.classList.toggle(
      "high-contrast",
      settings.highContrast
    );

    document.documentElement.classList.toggle(
      "reduced-motion",
      settings.reducedMotion
    );
  }, [settings]);

  // Navigate between application screens.
  const go = (id) => {
    if (id === "sos" || id === "emergency") {
      setEmergencyOpen(true);
      return;
    }

    setScreen(id);
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  // Browser speech synthesis.
  const speak = (message) => {
    setVoiceMessage(message);

    if (!settings.voiceEnabled) return;

    if (!("speechSynthesis" in window)) {
      setVoiceMessage("Speech output is not supported.");
      return;
    }

    window.speechSynthesis.cancel();

    const speech = new SpeechSynthesisUtterance(message);
    speech.rate = Number(settings.speechRate) || 1;
    speech.lang = "en-IN";

    window.speechSynthesis.speak(speech);
  };

  // Request the user's actual GPS location.
  const getLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported.");
      return;
    }

    setLocationLoading(true);
    setLocationError("");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;

        setLocation({
          latitude,
          longitude,
          accuracy: position.coords.accuracy,
        });

        setLocationLoading(false);
        speak("Your location has been updated.");
      },
      (error) => {
        setLocationLoading(false);
        setLocationError(error.message);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  };

  // Open directions using the user's current location.
  const openDirections = () => {
    const destination = window.prompt(
      "Enter your destination:"
    );

    if (!destination || !destination.trim()) return;

    const destinationText = encodeURIComponent(
      destination.trim()
    );

    let url =
      `https://www.google.com/maps/dir/?api=1` +
      `&destination=${destinationText}`;

    if (location) {
      url +=
        `&origin=${location.latitude},${location.longitude}`;
    }

    window.open(url, "_blank", "noopener,noreferrer");
  };

  const navCurrent = [
    "home",
    "navigation",
    "read",
  ].includes(screen)
    ? screen
    : "more";

  const isHome = screen === "home";

  return (
    <div className="app-shell ss-app">

      {!isHome && (
        <header className="ss-top">
          <button
            className="ss-brand"
            onClick={() => go("home")}
          >
            ● PathSense
          </button>

          <div>
            <strong>
              {TITLES[screen] || "PathSense"}
            </strong>

            <small>
              Your personal walking assistant
            </small>
          </div>
        </header>
      )}

      <main className="ss-main">

        {/* HOME */}
        {isHome && (
          <PathSenseDesign
            onGetStarted={() => go("features")}
            onFeatures={() => go("features")}
            onLearnMore={() => go("help")}
            onAbout={() => go("help")}
            onContact={() => go("help")}
            onSOS={() => setEmergencyOpen(true)}
            onNavigate={go}
          />
        )}

        {/* FEATURES */}
        {screen === "features" && (
          <div className="ss-wrap">

            <h1>PathSense Features</h1>

            <p>
              Choose an assistance feature to get started.
            </p>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(240px, 1fr))",
                gap: "20px",
                marginTop: "25px",
              }}
            >

              <FeatureCard
                title="Obstacle Detection"
                description="Use your camera for experimental object recognition."
                button="Start Camera"
                onClick={() => go("detect")}
              />

              <FeatureCard
                title="Live Navigation"
                description="Access your location and open walking directions."
                button="Open Navigation"
                onClick={() => go("navigation")}
              />

              <FeatureCard
                title="Voice Assistance"
                description="Listen to spoken assistance messages."
                button="Start Voice"
                onClick={() =>
                  speak("Welcome to PathSense voice assistance.")
                }
              />

              <FeatureCard
                title="Read Text"
                description="Open the text reading feature."
                button="Open Reader"
                onClick={() => go("read")}
              />

              <FeatureCard
                title="Guardian"
                description="Access guardian and safety options."
                button="Open Guardian"
                onClick={() => go("guardian")}
              />

              <FeatureCard
                title="Emergency SOS"
                description="Open the emergency assistance screen."
                button="Open SOS"
                onClick={() => setEmergencyOpen(true)}
              />

              <FeatureCard
                title="Settings"
                description="Customize accessibility and alert preferences."
                button="Open Settings"
                onClick={() => go("settings")}
              />

              <FeatureCard
                title="About & Help"
                description="Learn how to use PathSense."
                button="Learn More"
                onClick={() => go("help")}
              />

            </div>

            {voiceMessage && (
              <p role="status" style={{ marginTop: 20 }}>
                {voiceMessage}
              </p>
            )}

            <button
              onClick={() => go("home")}
              style={buttonStyle}
            >
              ← Back to Home
            </button>

          </div>
        )}

        {/* CAMERA AND OBJECT DETECTION */}
        {screen === "detect" && (
          <div className="ss-detect-wrap">

            <DetectionScreen
              settings={settings}
              detection={detection}
              onDetection={setDetection}
              onBack={() => go("features")}
              onSettings={() => go("settings")}
            />

          </div>
        )}

        {/* NAVIGATION */}
        {screen === "navigation" && (
          <div className="ss-wrap">

            <h1>Live Navigation</h1>

            <p>
              Get your current location and open directions.
            </p>

            <button
              style={buttonStyle}
              onClick={getLocation}
              disabled={locationLoading}
            >
              {locationLoading
                ? "Getting Location..."
                : "📍 Get My Location"}
            </button>

            {location && (
              <div style={panelStyle}>
                <h3>Current Location</h3>

                <p>
                  Latitude: {location.latitude.toFixed(6)}
                </p>

                <p>
                  Longitude: {location.longitude.toFixed(6)}
                </p>

                <p>
                  GPS accuracy: approximately{" "}
                  {Math.round(location.accuracy)} metres
                </p>
              </div>
            )}

            {locationError && (
              <p role="alert" style={{ color: "#b42318" }}>
                {locationError}
              </p>
            )}

            <button
              style={buttonStyle}
              onClick={openDirections}
            >
              🗺️ Open Directions
            </button>

            <button
              style={buttonStyle}
              onClick={() =>
                speak(
                  "PathSense navigation is ready. Use the location button to get your position."
                )
              }
            >
              🔊 Speak Instructions
            </button>

            <p>
              Directions open in Google Maps.
              PathSense does not independently verify
              pedestrian route safety.
            </p>

            <button
              style={buttonStyle}
              onClick={() => go("features")}
            >
              ← Back to Features
            </button>

          </div>
        )}

        {/* SETTINGS */}
        {screen === "settings" && (
          <div className="ss-wrap">

            <SettingsScreen
              settings={settings}
              setSettings={setSettings}
              onBack={() => go("features")}
            />

          </div>
        )}

        {/* HELP */}
        {screen === "help" && (
          <div className="ss-wrap">

            <HelpScreen
              onBack={() => go("features")}
            />

          </div>
        )}

        {/* EXISTING REFERENCE SCREENS */}
        {["read", "guardian", "more"].includes(screen) && (
          <ReferencePage
            screen={screen}
            onNavigate={go}
            onEmergency={() => setEmergencyOpen(true)}
          />
        )}

        {!isHome && (
          <div className="ss-warning">
            <Info size={17} />

            <span>
              Experimental assistance only.
              Object recognition does not establish
              distance, obstacle clearance, or route safety.
              Continue using established mobility aids.
            </span>
          </div>
        )}

      </main>

      {!isHome && (
        <BottomNavigation
          current={navCurrent}
          onNavigate={go}
        />
      )}

      {emergencyOpen && (
        <EmergencyScreen
          onClose={() => setEmergencyOpen(false)}
        />
      )}

    </div>
  );
}

function FeatureCard({
  title,
  description,
  button,
  onClick,
}) {
  return (
    <div
      style={{
        background: "#ffffff",
        borderRadius: "20px",
        padding: "25px",
        boxShadow: "0 8px 25px rgba(0,0,0,0.06)",
        border: "1px solid #d9ebe7",
      }}
    >
      <h2
        style={{
          color: "#173451",
          marginBottom: "12px",
        }}
      >
        {title}
      </h2>

      <p
        style={{
          color: "#486275",
          lineHeight: 1.6,
        }}
      >
        {description}
      </p>

      <button
        style={buttonStyle}
        onClick={onClick}
      >
        {button}
      </button>
    </div>
  );
}

const buttonStyle = {
  background: "#20a78f",
  color: "#ffffff",
  border: "none",
  padding: "13px 22px",
  borderRadius: "30px",
  cursor: "pointer",
  fontSize: "15px",
  fontWeight: "600",
  margin: "10px 10px 10px 0",
};

const panelStyle = {
  background: "#ffffff",
  borderRadius: "18px",
  padding: "20px",
  marginTop: "20px",
  marginBottom: "20px",
  border: "1px solid #d9ebe7",
};